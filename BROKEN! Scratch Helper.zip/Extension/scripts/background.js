chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
  if (message.action == "showPopup") {
    chrome.browserAction.setPopup({popup: "popup.html"});
  }
});
