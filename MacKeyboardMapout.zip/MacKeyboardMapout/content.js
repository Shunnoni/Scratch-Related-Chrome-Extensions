// Inject HTML with a button
const injectedHTML = `
  <div id="extension-div">
    <h1>The MacBook keyboard mapout</h1>
    <button id="extension-button">Keyboard Mapout</button>
  </div>

  <img src = "https://store.storeimages.cdn-apple.com/4982/as-images.apple.com/is/MK2A3?wid=1200&hei=630&fmt=jpeg&qlt=95&.v=1628010471000" alt = "The mini keyboard mapout."width=350   style="position: absolute; top: 10px; left: 680px;" id = "mapout">
`;
document.body.insertAdjacentHTML('afterbegin', injectedHTML);

// Inject JavaScript to handle button click
document.getElementById('extension-button').addEventListener('click', function() {
  // Get the image element by its ID
//const image = document.getElementById("mapout");

// Change the size of the image
//image.style.width = "530px"; // Set the width to 300 pixels
//image.style.height = "300px"; // Set the height to 200 pixels
// Assuming you already have a variable called 'image' referencing the image element

// Change the position of the image
//image.style.position = "absolute"; // Set the position to absolute
//image.style.top = "350px"; // Set the distance of the top edge from the top of the page to 50 pixels
//image.style.left = "50"; // Set the distance of the left edge from the left of the page to 50 pixels
window.open('https://www.canva.com/design/DAGEH7L4_Z0/ZWLEE6EnCpyP3ife4y9UAg/view?utm_content=DAGEH7L4_Z0&utm_campaign=designshare&utm_medium=link&utm_source=editor#1');

});

//document.getElementById('mapout').addEventListener('click', function() {
    // Get the image element by its ID
//const image = document.getElementById("mapout");

// Change the size of the image
//image.style.width = "240px"; // Set the width to 300 pixels
//image.style.height = "150px"; // Set the height to 200 pixels
// Assuming you already have a variable called 'image' referencing the image element

// Change the position of the image
//image.style.position = "absolute"; // Set the position to absolute
//image.style.top = "9px"; // Set the distance of the top edge from the top of the page to 50 pixels
//image.style.left = "700px"; // Set the distance of the left edge from the left of the page to 50 pixels
//});